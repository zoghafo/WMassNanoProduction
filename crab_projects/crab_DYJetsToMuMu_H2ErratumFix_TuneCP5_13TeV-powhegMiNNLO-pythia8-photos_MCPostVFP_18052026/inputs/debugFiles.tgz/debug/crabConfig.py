from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.workArea = 'crab_projects'
config.General.requestName = 'DYJetsToMuMu_H2ErratumFix_TuneCP5_13TeV-powhegMiNNLO-pythia8-photos_MCPostVFP_18052026'
config.section_('JobType')
config.JobType.psetName = '/home/z/zoghafoo/CMSSW_10_6_26/src/Configuration/WMassNanoProduction/configs/NanoV9MCPostVFP_DY_cfg.py'
config.JobType.pluginName = 'Analysis'
config.JobType.numCores = 1
config.JobType.maxMemoryMB = 3000
config.JobType.allowUndistributedCMSSW = True
config.section_('Data')
config.Data.inputDataset = '/DYJetsToMuMu_H2ErratumFix_TuneCP5_13TeV-powhegMiNNLO-pythia8-photos/RunIISummer20UL16MiniAODv2-106X_mcRun2_asymptotic_v17-v2/MINIAODSIM'
config.Data.outputDatasetTag = 'NanoV9MCPostVFP_DY_18052026'
config.Data.publication = True
config.Data.unitsPerJob = 1
config.Data.splitting = 'FileBased'
config.Data.inputDBS = 'global'
config.Data.useParent = False
config.Data.outLFNDirBase = '/store/user/zoghafoo/crabsubmission_files'
config.section_('Site')
config.Site.storageSite = 'T3_CH_PSI'
config.section_('User')
config.section_('Debug')
