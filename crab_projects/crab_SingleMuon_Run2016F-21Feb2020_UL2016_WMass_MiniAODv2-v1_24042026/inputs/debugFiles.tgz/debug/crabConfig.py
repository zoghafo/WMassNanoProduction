from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.workArea = 'crab_projects'
config.General.requestName = 'SingleMuon_Run2016F-21Feb2020_UL2016_WMass_MiniAODv2-v1_24042026'
config.section_('JobType')
config.JobType.psetName = '/home/z/zoghafoo/CMSSW_10_6_26/src/Configuration/WMassNanoProduction/configs/NanoV9DataPostVFP_cfgORIGINAL.py'
config.JobType.pluginName = 'Analysis'
config.JobType.numCores = 1
config.JobType.maxMemoryMB = 2000
config.JobType.allowUndistributedCMSSW = True
config.section_('Data')
config.Data.inputDataset = '/SingleMuon/Run2016F-21Feb2020_UL2016_WMass_MiniAODv2-v1/MINIAOD'
config.Data.outputDatasetTag = 'NanoV9Run2016FDataPostVFP_24042026'
config.Data.publication = True
config.Data.unitsPerJob = 10
config.Data.splitting = 'LumiBased'
config.Data.inputDBS = 'global'
config.Data.useParent = False
config.Data.outLFNDirBase = '/store/user/zoghafoo/crabsubmission_files'
config.section_('Site')
config.Site.storageSite = 'T3_CH_PSI'
config.section_('User')
config.section_('Debug')
